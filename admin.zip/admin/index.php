<?php
// Redirect to dashboard
header('Location: /admin/dashboard');
exit;
