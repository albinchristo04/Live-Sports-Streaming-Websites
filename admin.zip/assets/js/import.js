/**
 * import.js — Admin Import Page AJAX Logic
 * Site: https://news.evaulthub.com
 *
 * 1. "Fetch Matches" button  → POST /admin/import/fetch (server_id)
 *    Show loading spinner, then render preview table.
 * 2. Preview table checkbox per row: title, league, datetime, streams, status badge.
 * 3. "Import Selected" button → POST /admin/import/store (fingerprints[])
 *    Show result summary: "X imported, Y skipped".
 */
(function () {
  'use strict';

  /* ── Selectors / references ───────────────────────────────
     These IDs must exist in your PHP import view template.
  ──────────────────────────────────────────────────────── */
  var fetchBtn       = document.getElementById('btn-fetch-matches');
  var importBtn      = document.getElementById('btn-import-selected');
  var serverSelect   = document.getElementById('server-id');
  var previewSection = document.getElementById('import-preview-section');
  var previewTableBody = document.getElementById('import-table-body');
  var selectAllCb    = document.getElementById('select-all');
  var resultMsg      = document.getElementById('import-result');
  var spinnerEl      = document.getElementById('fetch-spinner');

  /* ── Helpers ─────────────────────────────────────────────── */

  function showSpinner(show) {
    if (!spinnerEl) return;
    spinnerEl.style.display = show ? 'inline-block' : 'none';
  }

  function setFetchBtnState(loading) {
    if (!fetchBtn) return;
    fetchBtn.disabled = loading;
    fetchBtn.textContent = loading ? 'Fetching…' : 'Fetch Matches';
  }

  function setImportBtnState(loading) {
    if (!importBtn) return;
    importBtn.disabled = loading;
    importBtn.textContent = loading ? 'Importing…' : 'Import Selected';
  }

  function showResult(msg, isError) {
    if (!resultMsg) return;
    resultMsg.textContent = msg;
    resultMsg.className = isError ? 'import-result text-danger' : 'import-result text-success';
    resultMsg.style.display = 'block';
  }

  function hideResult() {
    if (!resultMsg) return;
    resultMsg.style.display = 'none';
    resultMsg.textContent = '';
  }

  function getCsrfToken() {
    var meta = document.querySelector('meta[name="csrf-token"]');
    return meta ? meta.getAttribute('content') : '';
  }

  /* ── Date formatting ─────────────────────────────────────── */
  function formatDatetime(datetimeStr) {
    if (!datetimeStr) return '—';
    var d = new Date(datetimeStr);
    if (isNaN(d.getTime())) return datetimeStr;
    return d.toLocaleDateString('en-GB', {
      day   : '2-digit',
      month : 'short',
      year  : 'numeric',
      hour  : '2-digit',
      minute: '2-digit'
    });
  }

  /* ── Render preview table ─────────────────────────────────── */
  function renderPreviewTable(matches) {
    if (!previewTableBody) return;

    previewTableBody.innerHTML = '';

    if (!matches || matches.length === 0) {
      previewTableBody.innerHTML =
        '<tr><td colspan="6" class="text-center text-muted" style="padding:20px;">No matches found.</td></tr>';
      return;
    }

    matches.forEach(function (match) {
      var isNew     = match.status === 'new';
      var badgeClass = isNew ? 'status-badge status-new' : 'status-badge status-exists';
      var badgeText  = isNew ? 'New' : 'Exists';

      var streamCount = Array.isArray(match.streams) ? match.streams.length : 0;

      var tr = document.createElement('tr');
      tr.innerHTML =
        '<td><input type="checkbox" class="row-checkbox" ' +
          'value="' + escHtml(match.fingerprint) + '"' +
          (isNew ? '' : ' disabled') +
        '></td>' +
        '<td>' + escHtml(match.title || '—') + '</td>' +
        '<td>' + escHtml(match.league || '—') + '</td>' +
        '<td>' + escHtml(formatDatetime(match.datetime)) + '</td>' +
        '<td>' + streamCount + ' stream' + (streamCount !== 1 ? 's' : '') + '</td>' +
        '<td><span class="' + badgeClass + '">' + badgeText + '</span></td>';

      previewTableBody.appendChild(tr);
    });

    // Wire up select-all behaviour for freshly rendered checkboxes
    wireSelectAll();

    // Show the preview section
    if (previewSection) {
      previewSection.style.display = 'block';
    }
  }

  /* ── Select-all wiring ───────────────────────────────────── */
  function wireSelectAll() {
    if (!selectAllCb) return;

    // Remove old listener by cloning
    var fresh = selectAllCb.cloneNode(true);
    selectAllCb.parentNode.replaceChild(fresh, selectAllCb);
    selectAllCb = fresh;

    selectAllCb.checked = false;
    selectAllCb.indeterminate = false;

    selectAllCb.addEventListener('change', function () {
      var checkboxes = previewTableBody.querySelectorAll('.row-checkbox:not(:disabled)');
      checkboxes.forEach(function (cb) {
        cb.checked = selectAllCb.checked;
      });
    });

    previewTableBody.addEventListener('change', function (e) {
      if (!e.target.classList.contains('row-checkbox')) return;
      var all     = previewTableBody.querySelectorAll('.row-checkbox:not(:disabled)');
      var checked = previewTableBody.querySelectorAll('.row-checkbox:not(:disabled):checked');
      selectAllCb.checked = all.length > 0 && all.length === checked.length;
      selectAllCb.indeterminate = checked.length > 0 && checked.length < all.length;
    });
  }

  /* ── HTML escape ─────────────────────────────────────────── */
  function escHtml(str) {
    if (str == null) return '';
    return String(str)
      .replace(/&/g,  '&amp;')
      .replace(/</g,  '&lt;')
      .replace(/>/g,  '&gt;')
      .replace(/"/g,  '&quot;')
      .replace(/'/g,  '&#39;');
  }

  /* ── 1. Fetch Matches ─────────────────────────────────────── */
  function handleFetchMatches() {
    if (!fetchBtn) return;

    fetchBtn.addEventListener('click', function () {
      hideResult();

      var serverId = serverSelect ? serverSelect.value : '';
      if (!serverId) {
        showResult('Please select a server first.', true);
        return;
      }

      setFetchBtnState(true);
      showSpinner(true);

      var body = new URLSearchParams();
      body.append('server_id', serverId);

      fetch('/admin/import/fetch', {
        method : 'POST',
        headers: {
          'Content-Type' : 'application/x-www-form-urlencoded',
          'X-CSRF-Token' : getCsrfToken(),
          'X-Requested-With': 'XMLHttpRequest'
        },
        body: body.toString()
      })
      .then(function (response) {
        if (!response.ok) {
          return response.json().then(function (data) {
            throw new Error(data.message || 'Server error: ' + response.status);
          });
        }
        return response.json();
      })
      .then(function (data) {
        if (data.success === false) {
          throw new Error(data.message || 'Failed to fetch matches.');
        }
        renderPreviewTable(data.matches || data);
      })
      .catch(function (err) {
        showResult('Error: ' + err.message, true);
      })
      .finally(function () {
        setFetchBtnState(false);
        showSpinner(false);
      });
    });
  }

  /* ── 3. Import Selected ──────────────────────────────────── */
  function handleImportSelected() {
    if (!importBtn) return;

    importBtn.addEventListener('click', function () {
      hideResult();

      var checked = document.querySelectorAll('.row-checkbox:checked');
      if (checked.length === 0) {
        showResult('Please select at least one match to import.', true);
        return;
      }

      var fingerprints = [];
      checked.forEach(function (cb) {
        fingerprints.push(cb.value);
      });

      setImportBtnState(true);

      var body = new URLSearchParams();
      fingerprints.forEach(function (fp) {
        body.append('fingerprints[]', fp);
      });

      fetch('/admin/import/store', {
        method : 'POST',
        headers: {
          'Content-Type' : 'application/x-www-form-urlencoded',
          'X-CSRF-Token' : getCsrfToken(),
          'X-Requested-With': 'XMLHttpRequest'
        },
        body: body.toString()
      })
      .then(function (response) {
        if (!response.ok) {
          return response.json().then(function (data) {
            throw new Error(data.message || 'Server error: ' + response.status);
          });
        }
        return response.json();
      })
      .then(function (data) {
        if (data.success === false) {
          throw new Error(data.message || 'Import failed.');
        }

        var imported = data.imported || 0;
        var skipped  = data.skipped  || 0;
        showResult(
          imported + ' match' + (imported !== 1 ? 'es' : '') + ' imported' +
          (skipped > 0 ? ', ' + skipped + ' skipped.' : '.'),
          false
        );

        // Un-check imported rows and update their status badge
        checked.forEach(function (cb) {
          var row = cb.closest('tr');
          cb.checked  = false;
          cb.disabled = true;

          if (row) {
            var badge = row.querySelector('.status-badge');
            if (badge) {
              badge.className = 'status-badge status-exists';
              badge.textContent = 'Exists';
            }
          }
        });

        // Reset select-all
        if (selectAllCb) {
          selectAllCb.checked = false;
          selectAllCb.indeterminate = false;
        }
      })
      .catch(function (err) {
        showResult('Error: ' + err.message, true);
      })
      .finally(function () {
        setImportBtnState(false);
      });
    });
  }

  /* ── Bootstrap ───────────────────────────────────────────── */
  function init() {
    // Hide preview section initially
    if (previewSection) {
      previewSection.style.display = 'none';
    }
    if (resultMsg) {
      resultMsg.style.display = 'none';
    }
    if (spinnerEl) {
      spinnerEl.style.display = 'none';
    }

    handleFetchMatches();
    handleImportSelected();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
